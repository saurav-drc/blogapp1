package com.blogger.blogapp.entities;


public class Post {



}
