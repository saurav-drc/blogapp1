package com.blogger.blogapp.service;

import com.blogger.blogapp.payload.UserDto;

import java.util.List;

public interface UserService{

    UserDto createUser(UserDto user);
    UserDto updateUser(UserDto user,Long id);
    UserDto getUserById(Long id);
    List<UserDto> getALlUsers();
    void deleteUser(Long id);
}
